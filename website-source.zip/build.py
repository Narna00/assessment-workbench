from pathlib import Path
import base64,json,re
root=Path(__file__).parent
src=root/'site'
html=(src/'index.html').read_text(encoding='utf-8')
svg='data:image/svg+xml;base64,'+base64.b64encode((src/'mark.svg').read_bytes()).decode()
html=html.replace('./mark.svg',svg).replace('href="../"','href="./"')
html=html.replace('<link rel="stylesheet" href="./style.css">','<style>'+(src/'style.css').read_text(encoding='utf-8')+'</style>').replace('<script src="./app.js" defer></script>','')
downloads={p.name:base64.b64encode(p.read_bytes()).decode() for p in (src/'downloads').iterdir() if p.is_file()}
js=(src/'app.js').read_text(encoding='utf-8').replace("image.src='./mark.svg'",'image.src='+json.dumps(svg)).replace('el.href=url;','el.href=downloadURL(url);')
start="Promise.all([fetch('./catalog.json').then(r=>{if(!r.ok)throw new Error('Catalog unavailable');return r.json();}),fetch('./documents.json').then(r=>{if(!r.ok)throw new Error('Documents unavailable');return r.json();})])"
assert start in js
js=js.replace(start,'Promise.resolve([EMBEDDED_CATALOG,EMBEDDED_DOCUMENTS])')
prefix='const EMBEDDED_CATALOG='+(src/'catalog.json').read_text(encoding='utf-8')+';\nconst EMBEDDED_DOCUMENTS='+(src/'documents.json').read_text(encoding='utf-8')+';\nconst DOWNLOADS='+json.dumps(downloads)+';\nconst DOWNLOAD_URLS={};\nfunction downloadURL(url){if(!url.startsWith("downloads/"))return url;const key=url.slice(10);if(!DOWNLOADS[key])return url;if(!DOWNLOAD_URLS[key]){const bytes=Uint8Array.from(atob(DOWNLOADS[key]),c=>c.charCodeAt(0));DOWNLOAD_URLS[key]=URL.createObjectURL(new Blob([bytes],{type:key.endsWith(".zip")?"application/zip":"text/plain;charset=utf-8"}));}return DOWNLOAD_URLS[key];}\n'
html=html.replace('</body>','<script>'+re.sub(r'</script',r'<\\/script',prefix+js,flags=re.I)+'</script>\n</body>')
(root/'website.html').write_text(html,encoding='utf-8')
print('Built website.html')
